package feri.com.moviecatologue.modul.detail

interface DetailAction {
    fun onClickBack()
}