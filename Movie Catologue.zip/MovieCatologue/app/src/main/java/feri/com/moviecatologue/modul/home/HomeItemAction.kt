package feri.com.moviecatologue.modul.home

interface HomeItemAction {
    fun onClickDetail()
}